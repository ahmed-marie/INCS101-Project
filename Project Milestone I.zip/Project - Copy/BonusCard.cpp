#include "BonusCard.h"

//BonusCard::BonusCard() {}

BonusCard::BonusCard(int number, bool faceUp) : Card(number, faceUp) {};

BonusCard::~BonusCard() {}