#include "StandardCard.h"

//StandardCard::StandardCard() {}

StandardCard::StandardCard(int number, bool faceUp) : Card(number, faceUp) {};

StandardCard::~StandardCard() {}