#include "PenaltyCard.h"

//PenaltyCard::PenaltyCard() {}

PenaltyCard::PenaltyCard(int number, bool faceUp) : Card(number, faceUp) {};

PenaltyCard::~PenaltyCard() {}